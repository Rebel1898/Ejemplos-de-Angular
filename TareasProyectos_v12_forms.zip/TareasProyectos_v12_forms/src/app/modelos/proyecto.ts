export class Proyecto {

	pid:number;
	nombre:string;

	constructor (pid?:number,nombre?:string){
		this.pid = pid;
		this.nombre = nombre;
	}
}
